package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Admin {


private String product_id,product_name, amount, quantity,image;



public String getProduct_id() {
	return product_id;
}

public void setProduct_id(String product_id) {
	this.product_id = product_id;
}

public String getProduct_name() {
	return product_name;
}

public void setProduct_name(String product_name) {
	this.product_name = product_name;
}

public String getAmount() {
	return amount;
}

public void setAmount(String amount) {
	this.amount = amount;
}

public String getQuantity() {
	return quantity;
}

public void setQuantity(String quantity) {
	this.quantity = quantity;
}

public String getImage() {
	return image;
}

public void setImage(String image) {
	this.image = image;
}

//function for connection
public static Connection dbconnect() throws SQLException
{
	DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	
	String url = "jdbc:mysql://localhost:3306/my_project";
	String user = "root";
	String password = "";
	
	Connection conn = DriverManager.getConnection(url, user, password);
	return conn;
}

//for adding details
public int addProduct() throws SQLException
{
	Connection conn= dbconnect();
	
	/*DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	
	
	String url = "jdbc:mysql://localhost:3306/my_project";
	String user = "root";
	String password = "";
	
	Connection conn = DriverManager.getConnection(url, user, password);*/
	
	String sql = "insert into product values(?, ?, ?, ?, ?)";
	
	PreparedStatement ps = conn.prepareStatement(sql);
	ps.setString(1, product_id);
	ps.setString(2, product_name);
	ps.setString(3, amount);
	ps.setString(4, quantity);
	ps.setString(5, image);
	
	int Response = ps.executeUpdate();
	
	conn.close();
	
	return Response;
}

	public ArrayList<Admin> getMyAllProducts() throws SQLException
	{
		Connection conn= dbconnect();
		
		String sql = "select *from product";
		
		PreparedStatement pd = conn.prepareStatement(sql);
		
		ResultSet rs = pd.executeQuery();
		
		ArrayList<Admin> allProducts = new ArrayList<Admin>();
		
		while(rs.next())
		{
			Admin p = new Admin();
			p.setProduct_id(rs.getString("product_id"));
			p.setProduct_name(rs.getString("product_name"));
			p.setAmount(rs.getString("amount"));
			p.setImage(rs.getString("image"));
			
			allProducts.add(p);
		}
		
		return allProducts;
	}
	
	public Admin getProductbyid() throws SQLException {
		
		Connection conn = Admin.dbconnect();

		String sql = "select *from product where product_id =?";

		PreparedStatement pd = conn.prepareStatement(sql);
		pd.setString(1, product_id);

		ResultSet rs = pd.executeQuery();

		Admin p = new Admin();

		if(rs.next())
		{
			p.setProduct_id(rs.getString("product_id"));
			p.setProduct_name(rs.getString("product_name"));
			p.setImage(rs.getString("image"));
			p.setAmount(rs.getString("amount"));
			
		}
		else
		{
			p = null;
		}
		
		return p;
	}
    

	public static void main(String[] args) throws SQLException {
		Admin ad = new Admin();
		ArrayList<Admin> all = ad.getMyAllProducts();
		
		for(Admin aa: all)
		{
			System.out.println(aa.getProduct_name()+" "+aa.getAmount());
		}
	}
	
	
}