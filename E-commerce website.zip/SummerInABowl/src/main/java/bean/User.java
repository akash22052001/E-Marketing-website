package bean;

import java.sql.*;
import java.util.ArrayList;

public class User {

	
	private String userid,name, password, email;
	
	//getter setter for input details
	public String getUserid()
	{
		return userid;
	}
	
	public void setUserid(String userid)
	{
		this.userid = userid;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getPassword () 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	//function for connection
	public static Connection dbconnect() throws SQLException
	{
		DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		
		String url = "jdbc:mysql://localhost:3306/my_project";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	
	//for adding details
	public int addUser() throws SQLException
	{
		Connection conn= dbconnect();
		
		/*DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		
		
		String url = "jdbc:mysql://localhost:3306/my_project";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);*/
		
		String sql = "insert into user values(?, ?, ?, ?)";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userid);
		ps.setString(2, name);
		ps.setString(3, password);
		ps.setString(4, email);
		
		int Response = ps.executeUpdate();
		
		conn.close();
		
		return Response;
	}
	
	//for update
	public int updateUser() throws SQLException
	{
		
		Connection conn= dbconnect();
		
		String sql = "update user set name = ?,password=?,email=? where userid = ?";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userid);
		ps.setString(2, name);
		ps.setString(3, password);
		ps.setString(4, email);
	
		int response = ps.executeUpdate();
		
		conn.close();
		
		return response;
		}
	
	//for deletion
	public int deleteUser() throws SQLException
	{
		
		Connection conn= dbconnect();
		
		String sql = "delete from user where userid=?";
		
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, userid);
		
		int Res = ps.executeUpdate();
		
		conn.close();
		
		return Res;
		}
		
	//for displaying the details
		public ResultSet checkuserid() throws SQLException
		{
			
			Connection conn= dbconnect();
			
			String sql = "select * from user where userid=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, userid);
			ResultSet Res = ps.executeQuery();
			
			//conn.close();
			
			return Res;
			}
	 
	// for displaying all the details
		
	     // for login
	     public ResultSet userlogin() throws SQLException
			{
				
				Connection conn= dbconnect();
				
				String sql = "select * from user where email = ? and password = ?";
				
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1, email);
				ps.setString(2, password);
				
				
				ResultSet response = ps.executeQuery();
				
				//conn.close();
				
				return response;
		}
	}