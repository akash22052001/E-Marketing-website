package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.temporal.TemporalAmount;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import com.mysql.cj.xdevapi.Result;

public class Cart {

		private String email, productid, product_name,image; 	
		private int quantity;
		
		
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getProductid() {
			return productid;
		}
		public void setProductid(String productid) {
			this.productid = productid;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		
		
		public String getProduct_name() {
			return product_name;
		}
		public void setProduct_name(String product_name) {
			this.product_name = product_name;
		}
		
		
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		
		
		//for adding product to cart
		
		public int addToCart() throws SQLException
		{
			Connection conn = Admin.dbconnect() ;
			
			String sql = "insert into cart(email, productid, quantity) values (?,?,?)";
			
			PreparedStatement p = conn.prepareStatement(sql);
			
			p.setString(1, email);
			p.setString(2, productid);
			p.setInt(3, quantity);
			
			
			int response = p.executeUpdate();
			conn.close();
			
			return response;
			
		}
		
		//for counting the number of product in cart
		
		public int totalProductOfCart() throws SQLException
		{
			Connection conn = Admin.dbconnect();
			
			String sql = "select count(productid) as total from cart where email=?";
			
			PreparedStatement p = conn.prepareStatement(sql);			
			p.setString(1, email);
			
			ResultSet rs = p.executeQuery();
			int total = 0;
			if(rs.next()) {
				total = rs.getInt("total");
			}
			
			return total;
			
		}
		
		
		//for displaying all the cart items 	
		
		public ArrayList<Cart> getAllCartProduct() throws SQLException {
			
			
			Connection conn = Admin.dbconnect();

			String sql = "select *from cart where email =?";

			PreparedStatement pd = conn.prepareStatement(sql);
			pd.setString(1, email);

			ResultSet rs = pd.executeQuery();

			ArrayList<Cart> allCart = new ArrayList<Cart>();

			while(rs.next())
			{
				Cart p = new Cart();
				
				p.setProductid(rs.getString("productid"));
				p.setQuantity(rs.getInt("quantity"));
				
				allCart.add(p);
			}
			
			System.out.println(allCart.size());
			
			return allCart;
		}
		
		
		public boolean product() throws SQLException
		{
			
			Connection conn= Admin.dbconnect();
			
			String sql = "select *from product where productid=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, productid);
			ps.setString(2, product_name);
			ps.setString(3, image);
			
			
			
			ResultSet Res = ps.executeQuery();
		
			boolean res = false;
			
			if(Res.next())
			{
				res = true;
			}
			
			conn.close();
			return res;
			}
		
		
		
		//new start
		public int addInCart() throws SQLException
		{
			Connection conn = Admin.dbconnect();
			
			String sql = "insert into order(email, productid, quantity, product_name,image) values (?,?,?,?,?)";
			
			PreparedStatement p = conn.prepareStatement(sql);
			
			p.setString(1, email);
			p.setString(2, productid);
			p.setInt(3, quantity);
			p.setString(4, product_name);
			p.setString(5, image);
			
			
			int response = p.executeUpdate();
			conn.close();
			
			return response;
			
		}
		
		
		public static void main(String[] args) throws SQLException {
			Cart ad = new Cart();
			ad.setEmail("akash@gmail.com");
			ArrayList<Cart> all = ad.getAllCartProduct();
			System.out.println(all.size());
		}
		
	}
