package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;

@WebServlet (urlPatterns = "/signup")
public class RegisterServlet  extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String userid = req.getParameter("userid");
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		
		PrintWriter out = resp.getWriter();
		
		try {
			User s = new User();
			s.setUserid(userid);
			s.setName(name);
			s.setPassword(password);
			s.setEmail(email);
			
			int response = s.addUser();
			RequestDispatcher rd = req.getRequestDispatcher("signin.jsp");
			
			if(response == 1)
			  {
				
				req.setAttribute("message", "registration successful");
			  }
			else
			  {
				req.setAttribute("message", "registration failed");
			  }
				rd.forward(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
   
}