package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;

@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		String email = req.getParameter("email");
		String p = req.getParameter("password");
		
		
		PrintWriter out = resp.getWriter();
		
		
		try 
		{
			User obj = new User();
			obj.setEmail(email);
			obj.setPassword(p);
			
			ResultSet response = obj.userlogin();
			
			
			
			if(response.next())
			{
				Cookie email_Cookie = new Cookie("email", email);
				resp.addCookie(email_Cookie);
				
				HttpSession session = req.getSession();
				session.setAttribute("email", email);
				
				out.print("1");
			}
			else
			{
				
				out.print("0");
			}
			
		} 
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}