package servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import bean.Admin;

@WebServlet (urlPatterns = "/admin")


public class AdminServlet  extends HttpServlet
		{

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		MultipartRequest m = new MultipartRequest(req,"C:\\Users\\Akash Chowdhary\\eclipse-workspace\\FirstWebApplication\\SummerInABowl\\src\\main\\webapp\\img");
			
		
		
		String product_id = m.getParameter("product_id");
		String product_name = m.getParameter("product_name");
		String amount= m.getParameter("amount");
		String quantity  = m.getParameter("quantity");
		File file=m.getFile("image");
		
		String imagename = file.getName();
		String image_path= imagename;
		
		PrintWriter out = resp.getWriter();
		
		try {
			Admin s = new Admin();
			s.setProduct_id(product_id);
			s.setProduct_name(product_name);
			s.setAmount(amount);
			s.setQuantity(quantity);
			s.setImage(image_path);
			
			int response = s.addProduct();
			RequestDispatcher rd = req.getRequestDispatcher("product.jsp");
			
			if(response == 1)
			  {
				
				req.setAttribute("message", "product added successful");
			  }
			else
			  {
				req.setAttribute("message", "product addition  failed");
			  }
				rd.forward(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
   
}
