package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.EnquiryBean;

@WebServlet(urlPatterns = "/enquiry")
public class EnquiryServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String name = req.getParameter("name");
		String subject = req.getParameter("subject");
		String message = req.getParameter("message");
		
		EnquiryBean eb = new EnquiryBean();
		eb.setEmail(email);
		eb.setName(name);
		eb.setSubject(subject);
		eb.setMessage(message);
		
		try 
		{
			int response = eb.sendEnquiry();
			
			RequestDispatcher rd = req.getRequestDispatcher("contact.jsp");
			
			if(response == 1)
			{
				req.setAttribute("msg", "Message sent successfully");
			}
			else
			{
				req.setAttribute("msg", "Message not sent");
			}
			rd.forward(req, resp);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

